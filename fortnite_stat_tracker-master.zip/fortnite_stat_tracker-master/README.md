This is the code for my YouTube video on building a Fortnite Tracker in Flask. You can watch the video here: https://www.youtube.com/watch?v=_v9IOhHF4WI
